import { useState, useRef, useEffect } from 'react';
import { Play, Pause, Square, SkipBack, SkipForward, Volume2, Upload, Shuffle, Repeat } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Progress } from '@/components/ui/progress';

interface Track {
  id: string;
  name: string;
  file: File;
  url: string;
  duration: number;
}

export function MP3Player() {
  const [tracks, setTracks] = useState<Track[]>([]);
  const [currentTrack, setCurrentTrack] = useState<Track | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(75);
  const [shuffle, setShuffle] = useState(false);
  const [repeat, setRepeat] = useState(false);
  
  const audioRef = useRef<HTMLAudioElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files) return;

    Array.from(files).forEach((file) => {
      if (file.type.startsWith('audio/')) {
        const url = URL.createObjectURL(file);
        const audio = new Audio(url);
        
        audio.addEventListener('loadedmetadata', () => {
          const track: Track = {
            id: Math.random().toString(36).substr(2, 9),
            name: file.name.replace(/\.[^/.]+$/, ''),
            file,
            url,
            duration: audio.duration,
          };
          
          setTracks(prev => [...prev, track]);
          
          // Auto-play first track if none is selected
          if (!currentTrack) {
            setCurrentTrack(track);
          }
        });
      }
    });
  };

  const playTrack = (track: Track) => {
    if (audioRef.current) {
      audioRef.current.src = track.url;
      setCurrentTrack(track);
      setIsPlaying(true);
      audioRef.current.play();
    }
  };

  const togglePlayPause = () => {
    if (!audioRef.current || !currentTrack) return;

    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.play();
      setIsPlaying(true);
    }
  };

  const stopPlayback = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
      setIsPlaying(false);
      setCurrentTime(0);
    }
  };

  const nextTrack = () => {
    if (!currentTrack || tracks.length === 0) return;
    
    const currentIndex = tracks.findIndex(t => t.id === currentTrack.id);
    let nextIndex;
    
    if (shuffle) {
      nextIndex = Math.floor(Math.random() * tracks.length);
    } else {
      nextIndex = (currentIndex + 1) % tracks.length;
    }
    
    playTrack(tracks[nextIndex]);
  };

  const previousTrack = () => {
    if (!currentTrack || tracks.length === 0) return;
    
    const currentIndex = tracks.findIndex(t => t.id === currentTrack.id);
    const prevIndex = currentIndex === 0 ? tracks.length - 1 : currentIndex - 1;
    
    playTrack(tracks[prevIndex]);
  };

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setCurrentTime(audioRef.current.currentTime);
      setDuration(audioRef.current.duration || 0);
    }
  };

  const handleSeek = (value: number[]) => {
    if (audioRef.current) {
      audioRef.current.currentTime = value[0];
      setCurrentTime(value[0]);
    }
  };

  const handleVolumeChange = (value: number[]) => {
    const newVolume = value[0];
    setVolume(newVolume);
    if (audioRef.current) {
      audioRef.current.volume = newVolume / 100;
    }
  };

  const handleTrackEnd = () => {
    if (repeat) {
      if (audioRef.current) {
        audioRef.current.currentTime = 0;
        audioRef.current.play();
      }
    } else {
      nextTrack();
    }
  };

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('ended', handleTrackEnd);
    audio.volume = volume / 100;

    return () => {
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('ended', handleTrackEnd);
    };
  }, [volume, repeat]);

  return (
    <section className="mb-8">
      <h3 className="text-lg font-semibold mb-4 flex items-center">
        <Volume2 className="text-purple-500 mr-2 w-5 h-5" />
        MP3 Player
      </h3>
      
      <div className="bg-slate-800 rounded-xl border border-slate-600 p-4">
        
        {/* Upload Button */}
        <div className="mb-4">
          <input
            ref={fileInputRef}
            type="file"
            accept="audio/*"
            multiple
            onChange={handleFileUpload}
            className="hidden"
          />
          <Button 
            onClick={() => fileInputRef.current?.click()}
            className="w-full bg-purple-600 hover:bg-purple-700 text-white"
          >
            <Upload className="w-4 h-4 mr-2" />
            Add Music Files
          </Button>
        </div>

        {/* Current Track Display */}
        {currentTrack && (
          <div className="mb-4 p-3 bg-slate-750 rounded-lg">
            <div className="text-sm font-medium text-slate-200 truncate mb-1">
              {currentTrack.name}
            </div>
            <div className="text-xs text-slate-400">
              {formatTime(currentTime)} / {formatTime(duration)}
            </div>
          </div>
        )}

        {/* Progress Bar */}
        {currentTrack && (
          <div className="mb-4">
            <Slider
              value={[currentTime]}
              onValueChange={handleSeek}
              min={0}
              max={duration || 0}
              step={1}
              className="w-full"
            />
          </div>
        )}

        {/* Player Controls */}
        <div className="flex items-center justify-center space-x-2 mb-4">
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => setShuffle(!shuffle)}
            className={`${shuffle ? 'text-purple-400' : 'text-slate-400'} hover:text-purple-300`}
          >
            <Shuffle className="w-4 h-4" />
          </Button>
          
          <Button 
            variant="ghost" 
            size="icon"
            onClick={previousTrack}
            disabled={tracks.length === 0}
            className="text-slate-300 hover:text-white"
          >
            <SkipBack className="w-5 h-5" />
          </Button>
          
          <Button 
            onClick={togglePlayPause}
            disabled={!currentTrack}
            className="bg-purple-600 hover:bg-purple-700 text-white w-12 h-12"
          >
            {isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6" />}
          </Button>
          
          <Button 
            variant="ghost" 
            size="icon"
            onClick={nextTrack}
            disabled={tracks.length === 0}
            className="text-slate-300 hover:text-white"
          >
            <SkipForward className="w-5 h-5" />
          </Button>
          
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => setRepeat(!repeat)}
            className={`${repeat ? 'text-purple-400' : 'text-slate-400'} hover:text-purple-300`}
          >
            <Repeat className="w-4 h-4" />
          </Button>
          
          <Button 
            variant="ghost" 
            size="icon"
            onClick={stopPlayback}
            className="text-slate-400 hover:text-red-400"
          >
            <Square className="w-4 h-4" />
          </Button>
        </div>

        {/* Volume Control */}
        <div className="mb-4">
          <div className="flex items-center space-x-2">
            <Volume2 className="w-4 h-4 text-slate-400" />
            <Slider
              value={[volume]}
              onValueChange={handleVolumeChange}
              min={0}
              max={100}
              step={1}
              className="flex-1"
            />
            <span className="text-xs text-slate-400 w-8">{volume}%</span>
          </div>
        </div>

        {/* Playlist */}
        {tracks.length > 0 && (
          <div className="max-h-40 overflow-y-auto">
            <div className="text-xs font-medium text-slate-300 mb-2">Playlist ({tracks.length})</div>
            {tracks.map((track) => (
              <div
                key={track.id}
                onClick={() => playTrack(track)}
                className={`p-2 rounded cursor-pointer text-xs hover:bg-slate-700 ${
                  currentTrack?.id === track.id ? 'bg-purple-900/30 text-purple-300' : 'text-slate-400'
                }`}
              >
                <div className="truncate font-medium">{track.name}</div>
                <div className="text-xs text-slate-500">{formatTime(track.duration)}</div>
              </div>
            ))}
          </div>
        )}

        <audio ref={audioRef} />
      </div>
    </section>
  );
}