import { useEffect, useRef, useCallback, useState } from 'react';

interface VoicePatternMatcherProps {
  analyserNode: AnalyserNode | null;
  isRecording: boolean;
  targetFrequency: number;
  beatVolume: number;
}

export function VoicePatternMatcher({ 
  analyserNode, 
  isRecording, 
  targetFrequency,
  beatVolume 
}: VoicePatternMatcherProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationFrameRef = useRef<number>();
  const [matchQuality, setMatchQuality] = useState(0);

  const drawAudioTones = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;

    // Clear with dark background
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Draw center reference line
    ctx.strokeStyle = '#374151';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, canvas.height / 2);
    ctx.lineTo(canvas.width, canvas.height / 2);
    ctx.stroke();

    // Always show the target binaural beat pattern
    const time = Date.now() * 0.001;
    const baseFreq = 200; // Base carrier frequency
    const beatFreq = targetFrequency; // Beat frequency
    
    // Draw the binaural beat pattern (what the user should match)
    ctx.strokeStyle = '#f97316'; // Orange for target pattern
    ctx.lineWidth = 2;
    ctx.beginPath();
    
    for (let x = 0; x < canvas.width; x++) {
      // Create beat pattern visualization
      const t = (x / canvas.width) * 4 + time * 0.5;
      const leftEar = Math.sin(baseFreq * t * 0.02);
      const rightEar = Math.sin((baseFreq + beatFreq) * t * 0.02);
      const beatPattern = (leftEar + rightEar) * 0.5; // Combined pattern
      const amplitude = canvas.height * 0.3 * (beatVolume / 100);
      const y = canvas.height / 2 + beatPattern * amplitude;
      
      if (x === 0) {
        ctx.moveTo(x, y);
      } else {
        ctx.lineTo(x, y);
      }
    }
    ctx.stroke();

    // Show voice input analysis if available
    if (analyserNode && isRecording) {
      const bufferLength = analyserNode.fftSize;
      const dataArray = new Uint8Array(bufferLength);
      analyserNode.getByteTimeDomainData(dataArray);
      
      // Calculate voice pattern matching to beat rhythm (not frequency)
      // Analyze voice amplitude modulation to match beat pattern
      const voiceAmplitudes: number[] = [];
      for (let i = 0; i < bufferLength; i++) {
        voiceAmplitudes.push(Math.abs((dataArray[i] - 128) / 128.0));
      }
      
      // Generate target beat pattern for comparison
      const targetPattern: number[] = [];
      const beatPeriod = 44100 / targetFrequency; // Samples per beat cycle
      
      for (let i = 0; i < bufferLength; i++) {
        const beatPhase = (i % beatPeriod) / beatPeriod;
        const beatValue = (Math.sin(beatPhase * Math.PI * 2) + 1) * 0.5; // 0-1 range
        targetPattern.push(beatValue);
      }
      
      // Calculate correlation between voice rhythm and beat pattern
      let correlation = 0;
      let voiceTotal = 0;
      let targetTotal = 0;
      
      for (let i = 0; i < Math.min(voiceAmplitudes.length, targetPattern.length); i++) {
        correlation += voiceAmplitudes[i] * targetPattern[i];
        voiceTotal += voiceAmplitudes[i] * voiceAmplitudes[i];
        targetTotal += targetPattern[i] * targetPattern[i];
      }
      
      // Check if there's actual voice input (not feedback from speakers)
      let totalEnergy = 0;
      for (let i = 0; i < bufferLength; i++) {
        const sample = Math.abs((dataArray[i] - 128) / 128.0);
        totalEnergy += sample;
      }
      const avgEnergy = totalEnergy / bufferLength;
      
      let currentMatch = 0;
      // Only show match if there's significant voice input above speaker feedback level
      if (avgEnergy > 0.01) { // Higher threshold to avoid speaker feedback
        // Calculate correlation but only for actual voice input
        const normalizedCorrelation = voiceTotal > 0 && targetTotal > 0 
          ? correlation / Math.sqrt(voiceTotal * targetTotal)
          : 0;
        
        // Additional check - if the signal is too regular (like speaker output), reduce match
        let signalVariance = 0;
        for (let i = 1; i < Math.min(100, bufferLength); i++) {
          const diff = Math.abs((dataArray[i] - 128) - (dataArray[i-1] - 128));
          signalVariance += diff;
        }
        const avgVariance = signalVariance / 100;
        
        // If signal is too regular (low variance), it's likely speaker feedback
        if (avgVariance > 5) { // Real voice has more variance than speaker output
          currentMatch = Math.max(0, Math.min(100, Math.round(normalizedCorrelation * 100)));
        }
      }
      
      setMatchQuality(currentMatch);
      
      // Draw voice input as overlay
      ctx.strokeStyle = '#10b981'; // Green for voice input
      ctx.lineWidth = 1;
      ctx.globalAlpha = 0.7;
      ctx.beginPath();
      
      const sliceWidth = canvas.width / bufferLength;
      let x = 0;
      
      for (let i = 0; i < bufferLength; i++) {
        const v = (dataArray[i] - 128) / 128.0;
        const y = canvas.height / 2 + v * canvas.height * 0.2;
        
        if (i === 0) {
          ctx.moveTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
        x += sliceWidth;
      }
      ctx.stroke();
      ctx.globalAlpha = 1.0;
      
      // Draw match quality indicator
      ctx.fillStyle = currentMatch > 70 ? '#10b981' : currentMatch > 40 ? '#f59e0b' : '#ef4444';
      ctx.font = 'bold 16px monospace';
      ctx.fillText(`MATCH: ${currentMatch}%`, canvas.width - 120, 25);
      
      // Status text
      ctx.fillStyle = '#10b981';
      ctx.font = '11px monospace';
      ctx.fillText(`Voice Input (match ${targetFrequency}Hz rhythm pattern)`, 10, 20);
    } else {
      setMatchQuality(0);
    }

    if (!isRecording) {
      // Status text when not recording
      ctx.fillStyle = '#f97316';
      ctx.font = '11px monospace';
      ctx.fillText(`Target: ${targetFrequency}Hz Beat Pattern - Match rhythm with voice`, 10, 20);
    }
    
    // Bottom status
    ctx.fillStyle = '#94a3b8';
    ctx.font = '10px monospace';
    ctx.fillText(`${targetFrequency}Hz Binaural Beat | Volume: ${Math.round(beatVolume)}%`, 10, canvas.height - 10);
  }, [analyserNode, isRecording, targetFrequency, beatVolume]);

  useEffect(() => {
    const animate = () => {
      drawAudioTones();
      animationFrameRef.current = requestAnimationFrame(animate);
    };
    
    animate();
    
    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [drawAudioTones]);

  return (
    <canvas
      ref={canvasRef}
      className="w-full h-full bg-slate-900 rounded"
    />
  );
}