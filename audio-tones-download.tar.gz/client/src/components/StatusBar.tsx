import { useEffect, useState } from 'react';
import { Info } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface StatusBarProps {
  isRecording: boolean;
  sampleCount: number;
}

export function StatusBar({ isRecording, sampleCount }: StatusBarProps) {
  const [sessionDuration, setSessionDuration] = useState('00:00');
  const [startTime] = useState(Date.now());

  useEffect(() => {
    const interval = setInterval(() => {
      const elapsed = Math.floor((Date.now() - startTime) / 1000);
      const minutes = Math.floor(elapsed / 60);
      const seconds = elapsed % 60;
      setSessionDuration(`${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`);
    }, 1000);

    return () => clearInterval(interval);
  }, [startTime]);

  // Mock values for demonstration
  const bufferHealth = 98;
  const cpuUsage = 23;
  const audioLatency = 5.2;

  return (
    <footer className="bg-slate-750 border-t border-slate-600 px-6 py-3 flex items-center justify-between text-sm">
      <div className="flex items-center space-x-6">
        <div className="text-slate-400">
          Session: <span className="text-slate-200 font-mono">{sessionDuration}</span>
        </div>
        <div className="text-slate-400">
          Samples: <span className="text-slate-200 font-mono">{sampleCount.toLocaleString()}</span>
        </div>
        <div className="text-slate-400">
          Buffer: <span className="text-green-400 font-mono">{bufferHealth}%</span>
        </div>
      </div>
      
      <div className="flex items-center space-x-4">
        <div className="text-slate-400">
          CPU: <span className="text-slate-200 font-mono">{cpuUsage}%</span>
        </div>
        <div className="text-slate-400">
          Latency: <span className="text-slate-200 font-mono">{audioLatency}ms</span>
        </div>
        <Button 
          variant="ghost" 
          size="icon"
          className="text-slate-400 hover:text-slate-200"
          onClick={() => console.log('Showing debug info...')}
        >
          <Info className="w-4 h-4" />
        </Button>
      </div>
    </footer>
  );
}
