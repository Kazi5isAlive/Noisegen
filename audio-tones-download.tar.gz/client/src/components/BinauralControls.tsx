import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Headphones, Play, Square } from 'lucide-react';

interface BinauralControlsProps {
  isPlaying: boolean;
  frequencyRange: string;
  targetFrequency: number;
  beatVolume: number;
  error: string | null;
  onToggle: () => void;
  onFrequencyRangeChange: (range: 'delta' | 'theta' | 'alpha' | 'beta' | 'gamma') => void;
  onTargetFrequencyChange: (frequency: number) => void;
  onVolumeChange: (volume: number) => void;
}

export function BinauralControls({
  isPlaying,
  frequencyRange,
  targetFrequency,
  beatVolume,
  error,
  onToggle,
  onFrequencyRangeChange,
  onTargetFrequencyChange,
  onVolumeChange
}: BinauralControlsProps) {
  return (
    <section className="bg-slate-750 rounded-lg p-3 border border-slate-600">
      <h3 className="text-sm font-semibold mb-3 flex items-center text-blue-300">
        <Headphones className="mr-2 w-4 h-4" />
        Binaural Beats
      </h3>

      {/* Play/Stop Button */}
      <div className="mb-3">
        <Button 
          onClick={onToggle}
          size="sm"
          className={`w-full h-10 text-sm ${isPlaying ? "bg-blue-600 hover:bg-blue-700" : "bg-slate-600 hover:bg-slate-500"}`}
        >
          {isPlaying ? (
            <>
              <Square className="w-3 h-3 mr-2" />
              STOP
            </>
          ) : (
            <>
              <Play className="w-3 h-3 mr-2" />
              START
            </>
          )}
        </Button>
      </div>

      {/* Simplified Controls */}
      <div className="space-y-3">
        <div className="grid grid-cols-3 gap-1 text-xs">
          <button
            onClick={() => onFrequencyRangeChange('delta')}
            className={`p-1 rounded text-center ${
              frequencyRange === 'delta' ? 'bg-blue-600 text-white' : 'bg-slate-600 text-slate-300'
            }`}
          >
            Sleep
          </button>
          <button
            onClick={() => onFrequencyRangeChange('theta')}
            className={`p-1 rounded text-center ${
              frequencyRange === 'theta' ? 'bg-blue-600 text-white' : 'bg-slate-600 text-slate-300'
            }`}
          >
            Calm
          </button>
          <button
            onClick={() => onFrequencyRangeChange('alpha')}
            className={`p-1 rounded text-center ${
              frequencyRange === 'alpha' ? 'bg-blue-600 text-white' : 'bg-slate-600 text-slate-300'
            }`}
          >
            Relax
          </button>
          <button
            onClick={() => onFrequencyRangeChange('beta')}
            className={`p-2 rounded text-center ${
              frequencyRange === 'beta' ? 'bg-blue-600 text-white' : 'bg-slate-600 text-slate-300'
            }`}
          >
            Focus
          </button>
          <button
            onClick={() => onFrequencyRangeChange('gamma')}
            className={`p-2 rounded text-center ${
              frequencyRange === 'gamma' ? 'bg-blue-600 text-white' : 'bg-slate-600 text-slate-300'
            }`}
          >
            Alert
          </button>
        </div>

        {/* Volume Control */}
        <div>
          <label className="text-xs text-slate-400">Volume</label>
          <Slider
            value={[beatVolume]}
            onValueChange={(value) => onVolumeChange(value[0])}
            min={0}
            max={1}
            step={0.01}
            className="w-full mt-1"
          />
        </div>
      </div>

      {/* Error Display */}
      {error && (
        <div className="mt-3 p-2 bg-red-900/50 border border-red-500 rounded text-xs text-red-300">
          {error}
        </div>
      )}
    </section>
  );
}