import { useEffect, useRef, useCallback } from 'react';

interface WinampVisualizerProps {
  analyserNode: AnalyserNode | null;
  isActive: boolean;
  type?: 'bars' | 'oscilloscope' | 'spectrum';
}

export function WinampVisualizer({ analyserNode, isActive, type = 'bars' }: WinampVisualizerProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationFrameRef = useRef<number>();

  const drawBars = useCallback((ctx: CanvasRenderingContext2D, dataArray: Uint8Array, width: number, height: number) => {
    const barCount = 64;
    const barWidth = width / barCount;
    const step = Math.floor(dataArray.length / barCount);

    // Solid dark background
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(0, 0, width, height);

    for (let i = 0; i < barCount; i++) {
      const barHeight = (dataArray[i * step] / 255) * height;
      const x = i * barWidth;
      const y = height - barHeight;

      // Color gradient
      const hue = (i / barCount) * 120;
      ctx.fillStyle = `hsl(${hue}, 70%, 50%)`;
      ctx.fillRect(x, y, barWidth - 1, barHeight);

      // Peak highlight
      if (barHeight > height * 0.7) {
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(x, y, barWidth - 1, 2);
      }
    }
  }, []);

  const drawVisualization = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas || !analyserNode) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;

    const bufferLength = analyserNode.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);
    analyserNode.getByteFrequencyData(dataArray);

    drawBars(ctx, dataArray, canvas.width, canvas.height);

    if (isActive) {
      animationFrameRef.current = requestAnimationFrame(drawVisualization);
    }
  }, [analyserNode, isActive, drawBars]);

  useEffect(() => {
    if (isActive && analyserNode) {
      drawVisualization();
    } else {
      // Draw empty state
      const canvas = canvasRef.current;
      if (canvas) {
        const ctx = canvas.getContext('2d');
        if (ctx) {
          canvas.width = canvas.offsetWidth;
          canvas.height = canvas.offsetHeight;
          
          // Solid background
          ctx.fillStyle = '#1e293b';
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          
          // Empty bars
          const barCount = 64;
          const barWidth = canvas.width / barCount;
          
          for (let i = 0; i < barCount; i++) {
            const x = i * barWidth;
            const y = canvas.height - 2;
            
            ctx.fillStyle = '#374151';
            ctx.fillRect(x, y, barWidth - 1, 2);
          }
        }
      }
    }

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [drawVisualization, isActive, analyserNode]);

  return (
    <div className="w-full h-full relative">
      <canvas
        ref={canvasRef}
        className="w-full h-full"
        style={{ background: '#1e293b' }}
      />
    </div>
  );
}