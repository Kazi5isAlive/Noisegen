import { useEffect, useRef, useCallback } from 'react';
import { Hexagon, Triangle, Circle, Square } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface SacredGeometryProps {
  frequencyBins: number[];
  targetFrequency: number;
  isActive: boolean;
}

export function SacredGeometry({ frequencyBins, targetFrequency, isActive }: SacredGeometryProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationFrameRef = useRef<number>();
  const timeRef = useRef(0);

  const drawFlowerOfLife = useCallback((ctx: CanvasRenderingContext2D, centerX: number, centerY: number, radius: number, intensity: number) => {
    const circles = 7; // Classic Flower of Life has 7 circles
    const angleStep = (Math.PI * 2) / 6;
    
    ctx.strokeStyle = `hsla(${240 + intensity * 120}, 70%, ${50 + intensity * 30}%, ${0.3 + intensity * 0.7})`;
    ctx.lineWidth = 2;
    
    // Center circle
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius * (0.5 + intensity * 0.5), 0, Math.PI * 2);
    ctx.stroke();
    
    // Surrounding circles
    for (let i = 0; i < 6; i++) {
      const x = centerX + Math.cos(angleStep * i) * radius * 0.7;
      const y = centerY + Math.sin(angleStep * i) * radius * 0.7;
      
      ctx.beginPath();
      ctx.arc(x, y, radius * (0.4 + intensity * 0.4), 0, Math.PI * 2);
      ctx.stroke();
    }
  }, []);

  const drawSriYantra = useCallback((ctx: CanvasRenderingContext2D, centerX: number, centerY: number, size: number, intensity: number) => {
    const triangleSize = size * (0.3 + intensity * 0.4);
    
    ctx.strokeStyle = `hsla(${30 + intensity * 60}, 80%, ${40 + intensity * 40}%, ${0.4 + intensity * 0.6})`;
    ctx.lineWidth = 1.5;
    
    // Upward triangles
    for (let i = 0; i < 4; i++) {
      const scale = 1 - (i * 0.2);
      const currentSize = triangleSize * scale;
      
      ctx.beginPath();
      ctx.moveTo(centerX, centerY - currentSize);
      ctx.lineTo(centerX - currentSize * 0.866, centerY + currentSize * 0.5);
      ctx.lineTo(centerX + currentSize * 0.866, centerY + currentSize * 0.5);
      ctx.closePath();
      ctx.stroke();
    }
    
    // Downward triangles
    for (let i = 0; i < 4; i++) {
      const scale = 1 - (i * 0.2);
      const currentSize = triangleSize * scale * 0.8;
      
      ctx.beginPath();
      ctx.moveTo(centerX, centerY + currentSize);
      ctx.lineTo(centerX - currentSize * 0.866, centerY - currentSize * 0.5);
      ctx.lineTo(centerX + currentSize * 0.866, centerY - currentSize * 0.5);
      ctx.closePath();
      ctx.stroke();
    }
  }, []);

  const drawMeridianFlower = useCallback((ctx: CanvasRenderingContext2D, centerX: number, centerY: number, radius: number, intensity: number, time: number) => {
    const petals = 8;
    const angleStep = (Math.PI * 2) / petals;
    
    ctx.strokeStyle = `hsla(${300 + intensity * 60}, 70%, ${50 + intensity * 30}%, ${0.3 + intensity * 0.5})`;
    ctx.lineWidth = 1;
    
    for (let i = 0; i < petals; i++) {
      const angle = angleStep * i + time * 0.001;
      const petalRadius = radius * (0.4 + intensity * 0.4);
      const x1 = centerX + Math.cos(angle) * petalRadius;
      const y1 = centerY + Math.sin(angle) * petalRadius;
      
      // Create petal shape
      ctx.beginPath();
      ctx.arc(x1, y1, petalRadius * 0.3, 0, Math.PI * 2);
      ctx.stroke();
      
      // Connect to center
      ctx.beginPath();
      ctx.moveTo(centerX, centerY);
      ctx.lineTo(x1, y1);
      ctx.stroke();
    }
  }, []);

  const drawCymatics = useCallback((ctx: CanvasRenderingContext2D, width: number, height: number, frequencyBins: number[], time: number) => {
    if (!isActive) return;
    
    const centerX = width / 2;
    const centerY = height / 2;
    const maxRadius = Math.min(width, height) * 0.4;
    
    // Clear canvas with slight fade effect for trails
    ctx.fillStyle = 'rgba(15, 23, 42, 0.1)';
    ctx.fillRect(0, 0, width, height);
    
    // Calculate overall intensity from frequency bins
    const totalEnergy = frequencyBins.reduce((sum, bin) => sum + bin, 0) / frequencyBins.length;
    const intensity = Math.min(totalEnergy * 2, 1);
    
    // Draw different sacred geometry patterns based on target frequency
    if (targetFrequency <= 4) {
      // Delta waves - Flower of Life
      drawFlowerOfLife(ctx, centerX, centerY, maxRadius, intensity);
    } else if (targetFrequency <= 8) {
      // Theta waves - Sri Yantra
      drawSriYantra(ctx, centerX, centerY, maxRadius, intensity);
    } else if (targetFrequency <= 13) {
      // Alpha waves - Meridian Flower
      drawMeridianFlower(ctx, centerX, centerY, maxRadius, intensity, time);
    } else {
      // Beta/Gamma waves - Complex mandala
      drawFlowerOfLife(ctx, centerX, centerY, maxRadius * 0.6, intensity);
      drawMeridianFlower(ctx, centerX, centerY, maxRadius * 1.2, intensity * 0.7, time);
    }
    
    // Add frequency-responsive particles
    for (let i = 0; i < frequencyBins.length; i++) {
      const binIntensity = frequencyBins[i];
      if (binIntensity > 0.1) {
        const angle = (i / frequencyBins.length) * Math.PI * 2 + time * 0.001;
        const distance = maxRadius * (0.7 + binIntensity * 0.5);
        const x = centerX + Math.cos(angle) * distance;
        const y = centerY + Math.sin(angle) * distance;
        
        ctx.fillStyle = `hsla(${i * 20 + time * 0.1}, 70%, 60%, ${binIntensity})`;
        ctx.beginPath();
        ctx.arc(x, y, 2 + binIntensity * 4, 0, Math.PI * 2);
        ctx.fill();
      }
    }
    
    // Add central mandala
    ctx.strokeStyle = `hsla(${180 + time * 0.05}, 60%, 50%, ${0.5 + intensity * 0.5})`;
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(centerX, centerY, 20 + intensity * 30, 0, Math.PI * 2);
    ctx.stroke();
    
    // Inner sacred circle
    ctx.strokeStyle = `hsla(${time * 0.1}, 80%, 70%, ${intensity})`;
    ctx.beginPath();
    ctx.arc(centerX, centerY, 5 + intensity * 15, 0, Math.PI * 2);
    ctx.stroke();
  }, [isActive, targetFrequency, drawFlowerOfLife, drawSriYantra, drawMeridianFlower]);

  const animate = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;

    timeRef.current += 16; // Approximate 60fps
    drawCymatics(ctx, canvas.width, canvas.height, frequencyBins, timeRef.current);

    animationFrameRef.current = requestAnimationFrame(animate);
  }, [frequencyBins, drawCymatics]);

  useEffect(() => {
    if (isActive) {
      animate();
    } else {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    }

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [animate, isActive]);

  return (
    <section>
      <div className="flex justify-between items-center mb-3">
        <h4 className="text-sm font-medium text-slate-300 flex items-center">
          <Hexagon className="w-4 h-4 text-indigo-400 mr-2" />
          Sacred Geometry Cymatics
        </h4>
        <div className="flex space-x-1">
          <Circle className="w-3 h-3 text-blue-400" />
          <Triangle className="w-3 h-3 text-yellow-400" />
          <Square className="w-3 h-3 text-green-400" />
          <Hexagon className="w-3 h-3 text-purple-400" />
        </div>
      </div>
      
      <div className="bg-slate-900 rounded-xl border border-slate-600 relative overflow-hidden">
        <canvas 
          ref={canvasRef}
          className="w-full h-64"
          style={{ background: 'radial-gradient(circle, rgba(15,23,42,1) 0%, rgba(7,12,23,1) 100%)' }}
        />
        
        {!isActive && (
          <div className="absolute inset-0 flex items-center justify-center bg-slate-900/80">
            <div className="text-center">
              <Hexagon className="w-8 h-8 text-slate-500 mx-auto mb-2" />
              <p className="text-sm text-slate-400">Start audio to activate cymatics</p>
            </div>
          </div>
        )}
        
        <div className="absolute bottom-2 left-2 text-xs text-slate-500">
          {targetFrequency <= 4 ? 'Flower of Life' : 
           targetFrequency <= 8 ? 'Sri Yantra' :
           targetFrequency <= 13 ? 'Meridian Flower' : 'Complex Mandala'}
        </div>
      </div>
    </section>
  );
}