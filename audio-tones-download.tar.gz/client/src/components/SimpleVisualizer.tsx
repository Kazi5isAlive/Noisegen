import { useEffect, useRef, useCallback } from 'react';

interface SimpleVisualizerProps {
  analyserNode: AnalyserNode | null;
  isActive: boolean;
  width?: number;
  height?: number;
}

export function SimpleVisualizer({ analyserNode, isActive, width = 400, height = 100 }: SimpleVisualizerProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationFrameRef = useRef<number>();

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas || !analyserNode || !isActive) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas dimensions
    canvas.width = width;
    canvas.height = height;

    // Get frequency data
    const bufferLength = analyserNode.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);
    analyserNode.getByteFrequencyData(dataArray);

    // Clear canvas
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(0, 0, width, height);

    // Draw frequency bars
    const barWidth = width / 50; // Show 50 bars
    const step = Math.floor(bufferLength / 50);

    for (let i = 0; i < 50; i++) {
      const magnitude = dataArray[i * step] || 0;
      const barHeight = (magnitude / 255) * height;
      
      const x = i * barWidth;
      const y = height - barHeight;

      // Color based on frequency range
      const hue = (i / 50) * 120; // Green to red
      ctx.fillStyle = `hsl(${hue}, 70%, 50%)`;
      ctx.fillRect(x, y, barWidth - 1, barHeight);
    }

    if (isActive) {
      animationFrameRef.current = requestAnimationFrame(draw);
    }
  }, [analyserNode, isActive, width, height]);

  useEffect(() => {
    if (isActive && analyserNode) {
      draw();
    } else {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    }

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [draw, isActive, analyserNode]);

  return (
    <canvas 
      ref={canvasRef}
      width={width}
      height={height}
      className="border border-slate-600 rounded bg-slate-900"
      style={{ width: `${width}px`, height: `${height}px` }}
    />
  );
}