import { useState, useRef, useEffect, useCallback } from 'react';
import { RotateCcw, Target, Volume2 } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface CymaticsDialProps {
  targetFrequency: number;
  currentFrequency: number;
  onTargetChange: (frequency: number) => void;
  matchQuality: number;
  isActive: boolean;
}

export function CymaticsDial({ 
  targetFrequency, 
  currentFrequency, 
  onTargetChange, 
  matchQuality,
  isActive 
}: CymaticsDialProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [dialAngle, setDialAngle] = useState(0);
  const dialRef = useRef<SVGSVGElement>(null);
  const centerRef = useRef({ x: 0, y: 0 });

  // Convert frequency to angle (0-360 degrees for 0.5-50 Hz range)
  const frequencyToAngle = useCallback((freq: number) => {
    const clampedFreq = Math.max(0.5, Math.min(50, freq));
    return ((clampedFreq - 0.5) / 49.5) * 360;
  }, []);

  // Convert angle to frequency
  const angleToFrequency = useCallback((angle: number) => {
    const normalizedAngle = ((angle % 360) + 360) % 360;
    return 0.5 + (normalizedAngle / 360) * 49.5;
  }, []);

  // Calculate angle from mouse position
  const getAngleFromMouse = useCallback((clientX: number, clientY: number) => {
    const rect = dialRef.current?.getBoundingClientRect();
    if (!rect) return 0;

    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    
    const deltaX = clientX - centerX;
    const deltaY = clientY - centerY;
    
    let angle = Math.atan2(deltaY, deltaX) * (180 / Math.PI);
    angle = (angle + 90 + 360) % 360; // Normalize to 0-360, starting from top
    
    return angle;
  }, []);

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    const angle = getAngleFromMouse(e.clientX, e.clientY);
    setDialAngle(angle);
    onTargetChange(angleToFrequency(angle));
  };

  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (!isDragging) return;
    
    const angle = getAngleFromMouse(e.clientX, e.clientY);
    setDialAngle(angle);
    onTargetChange(angleToFrequency(angle));
  }, [isDragging, getAngleFromMouse, angleToFrequency, onTargetChange]);

  const handleMouseUp = useCallback(() => {
    setIsDragging(false);
  }, []);

  useEffect(() => {
    if (isDragging) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
    }

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging, handleMouseMove, handleMouseUp]);

  // Update dial angle when target frequency changes externally
  useEffect(() => {
    if (!isDragging) {
      setDialAngle(frequencyToAngle(targetFrequency));
    }
  }, [targetFrequency, frequencyToAngle, isDragging]);

  const resetToCurrentFrequency = () => {
    const newAngle = frequencyToAngle(currentFrequency);
    setDialAngle(newAngle);
    onTargetChange(currentFrequency);
  };

  // Generate frequency markers
  const markers = [];
  const majorFreqs = [1, 2, 4, 8, 13, 30, 50];
  const labels = ['1', '2', '4θ', '8α', '13β', '30γ', '50'];
  
  for (let i = 0; i < majorFreqs.length; i++) {
    const freq = majorFreqs[i];
    const angle = frequencyToAngle(freq);
    const radians = (angle - 90) * (Math.PI / 180);
    const x1 = 95 + Math.cos(radians) * 35;
    const y1 = 95 + Math.sin(radians) * 35;
    const x2 = 95 + Math.cos(radians) * 45;
    const y2 = 95 + Math.sin(radians) * 45;
    const textX = 95 + Math.cos(radians) * 55;
    const textY = 95 + Math.sin(radians) * 55;

    markers.push(
      <g key={freq}>
        <line x1={x1} y1={y1} x2={x2} y2={y2} stroke="#64748b" strokeWidth="2" />
        <text 
          x={textX} 
          y={textY} 
          textAnchor="middle" 
          dominantBaseline="middle" 
          className="text-xs fill-slate-400"
          fontSize="10"
        >
          {labels[i]}
        </text>
      </g>
    );
  }

  // Current frequency indicator
  const currentAngle = frequencyToAngle(currentFrequency);
  const currentRadians = (currentAngle - 90) * (Math.PI / 180);
  const currentX = 95 + Math.cos(currentRadians) * 40;
  const currentY = 95 + Math.sin(currentRadians) * 40;

  // Target frequency pointer
  const targetRadians = (dialAngle - 90) * (Math.PI / 180);
  const pointerX = 95 + Math.cos(targetRadians) * 30;
  const pointerY = 95 + Math.sin(targetRadians) * 30;

  return (
    <section>
      <div className="flex justify-between items-center mb-3">
        <h4 className="text-sm font-medium text-slate-300 flex items-center">
          <Target className="w-4 h-4 text-orange-400 mr-2" />
          Cymatics Frequency Dial
        </h4>
        <Button
          variant="ghost"
          size="sm"
          onClick={resetToCurrentFrequency}
          className="text-xs text-slate-400 hover:text-orange-400"
        >
          <RotateCcw className="w-3 h-3 mr-1" />
          Match Voice
        </Button>
      </div>
      
      <div className="bg-slate-800 rounded-xl border border-slate-600 p-4 relative">
        
        {/* Main Dial */}
        <div className="flex justify-center mb-4">
          <svg
            ref={dialRef}
            width="190"
            height="190"
            viewBox="0 0 190 190"
            className="cursor-pointer select-none"
            onMouseDown={handleMouseDown}
          >
            {/* Outer ring */}
            <circle
              cx="95"
              cy="95"
              r="85"
              fill="none"
              stroke="#475569"
              strokeWidth="2"
            />
            
            {/* Inner ring */}
            <circle
              cx="95"
              cy="95"
              r="65"
              fill="none"
              stroke="#334155"
              strokeWidth="1"
            />
            
            {/* Match quality arc */}
            <circle
              cx="95"
              cy="95"
              r="75"
              fill="none"
              stroke={matchQuality > 70 ? '#10b981' : matchQuality > 40 ? '#f59e0b' : '#ef4444'}
              strokeWidth="4"
              strokeDasharray={`${(matchQuality / 100) * 471.24} 471.24`}
              strokeDashoffset="-117.81"
              opacity={isActive ? 0.8 : 0.3}
              className="transition-all duration-300"
            />
            
            {/* Frequency markers */}
            {markers}
            
            {/* Current frequency indicator */}
            {isActive && (
              <circle
                cx={currentX}
                cy={currentY}
                r="4"
                fill="#3b82f6"
                className="animate-pulse"
              />
            )}
            
            {/* Target frequency pointer */}
            <g transform={`rotate(${dialAngle} 95 95)`}>
              <line
                x1="95"
                y1="95"
                x2="95"
                y2="35"
                stroke="#f97316"
                strokeWidth="3"
                strokeLinecap="round"
              />
              <circle
                cx="95"
                cy="35"
                r="6"
                fill="#f97316"
              />
            </g>
            
            {/* Center hub */}
            <circle
              cx="95"
              cy="95"
              r="15"
              fill="#1e293b"
              stroke="#475569"
              strokeWidth="2"
            />
            
            {/* Center dot */}
            <circle
              cx="95"
              cy="95"
              r="3"
              fill="#f97316"
            />
          </svg>
        </div>
        
        {/* Frequency Display */}
        <div className="grid grid-cols-2 gap-4 text-center">
          <div className="bg-slate-750 rounded-lg p-3">
            <div className="text-xs text-slate-400 mb-1">Target</div>
            <div className="text-lg font-mono text-orange-400">
              {targetFrequency.toFixed(1)} Hz
            </div>
          </div>
          <div className="bg-slate-750 rounded-lg p-3">
            <div className="text-xs text-slate-400 mb-1">Voice</div>
            <div className="text-lg font-mono text-blue-400">
              {currentFrequency.toFixed(1)} Hz
            </div>
          </div>
        </div>
        
        {/* Match Quality Indicator */}
        <div className="mt-4">
          <div className="flex justify-between items-center mb-2">
            <span className="text-xs text-slate-400">Cymatics Match</span>
            <span className="text-xs font-mono text-orange-400">{matchQuality}%</span>
          </div>
          <div className="w-full bg-slate-700 rounded-full h-2">
            <div 
              className={`h-2 rounded-full transition-all duration-300 ${
                matchQuality > 70 ? 'bg-green-500' : 
                matchQuality > 40 ? 'bg-yellow-500' : 'bg-red-500'
              }`}
              style={{ width: `${matchQuality}%` }}
            />
          </div>
        </div>
        
        {/* Instructions */}
        <div className="mt-3 text-xs text-slate-500 text-center">
          Drag the dial to set target frequency for sacred geometry patterns
        </div>
      </div>
    </section>
  );
}