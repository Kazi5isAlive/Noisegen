import { useState } from 'react';
import { Headphones, Mic, TrendingUp, Play, Pause, Square, Target } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { AdvancedControlPanel } from './AdvancedControlPanel';
import { MP3Player } from './MP3Player';

interface ControlSidebarProps {
  // Binaural beats props
  isPlayingBeats: boolean;
  frequencyRange: string;
  targetFrequency: number;
  beatVolume: number;
  onToggleBinauralBeats: () => void;
  onStopBinauralBeats: () => void;
  onFrequencyRangeChange: (range: 'delta' | 'theta' | 'alpha' | 'beta' | 'gamma') => void;
  onTargetFrequencyChange: (frequency: number) => void;
  onBeatVolumeChange: (volume: number) => void;
  
  // Advanced features
  whiteNoiseEnabled: boolean;
  whiteNoiseVolume: number;
  whiteNoiseFrequency: number;
  onWhiteNoiseEnabledChange: (enabled: boolean) => void;
  onWhiteNoiseVolumeChange: (volume: number) => void;
  onWhiteNoiseFrequencyChange: (frequency: number) => void;
  isochronicEnabled: boolean;
  isochronicRate: number;
  onIsochronicEnabledChange: (enabled: boolean) => void;
  onIsochronicRateChange: (rate: number) => void;
  frequencySweepEnabled: boolean;
  sweepMin: number;
  sweepMax: number;
  onFrequencySweepEnabledChange: (enabled: boolean) => void;
  onSweepMinChange: (min: number) => void;
  onSweepMaxChange: (max: number) => void;
  dualBeatsEnabled: boolean;
  secondaryBeat: number;
  onDualBeatsEnabledChange: (enabled: boolean) => void;
  onSecondaryBeatChange: (beat: number) => void;

  
  // Microphone props
  isRecording: boolean;
  inputLevel: number;
  inputGain: number;
  microphoneError: string | null;
  onToggleRecording: () => void;
  onInputGainChange: (gain: number) => void;
  
  // Analysis props
  matchQuality: number;
  frequencyDeviation: number;
  inputFrequency: number;
}

export function ControlSidebar({
  isPlayingBeats,
  frequencyRange,
  targetFrequency,
  beatVolume,
  onToggleBinauralBeats,
  onStopBinauralBeats,
  onFrequencyRangeChange,
  onTargetFrequencyChange,
  onBeatVolumeChange,
  whiteNoiseEnabled,
  whiteNoiseVolume,
  whiteNoiseFrequency,
  onWhiteNoiseEnabledChange,
  onWhiteNoiseVolumeChange,
  onWhiteNoiseFrequencyChange,
  isochronicEnabled,
  isochronicRate,
  onIsochronicEnabledChange,
  onIsochronicRateChange,
  frequencySweepEnabled,
  sweepMin,
  sweepMax,
  onFrequencySweepEnabledChange,
  onSweepMinChange,
  onSweepMaxChange,
  dualBeatsEnabled,
  secondaryBeat,
  onDualBeatsEnabledChange,
  onSecondaryBeatChange,
  isRecording,
  inputLevel,
  inputGain,
  microphoneError,
  onToggleRecording,
  onInputGainChange,
  matchQuality,
  frequencyDeviation,
  inputFrequency,
}: ControlSidebarProps) {
  
  const getFrequencyRange = () => {
    switch (frequencyRange) {
      case 'delta': return { min: 0.5, max: 4 };
      case 'theta': return { min: 4, max: 8 };
      case 'alpha': return { min: 8, max: 13 };
      case 'beta': return { min: 13, max: 30 };
      case 'gamma': return { min: 30, max: 100 };
      default: return { min: 4, max: 8 };
    }
  };

  const range = getFrequencyRange();

  // Generate input level bars
  const levelBars = [];
  const barCount = 7;
  for (let i = 0; i < barCount; i++) {
    const threshold = (i / barCount) * 100;
    const isActive = inputLevel > threshold;
    const height = 3 + (i * 3); // Heights from 3 to 21
    
    let colorClass = 'bg-slate-600';
    if (isActive) {
      if (i < 3) colorClass = 'bg-green-500';
      else if (i < 5) colorClass = 'bg-yellow-500';
      else colorClass = 'bg-orange-500';
    }
    
    levelBars.push(
      <div
        key={i}
        className={`audio-bar w-2 rounded-sm transition-colors ${colorClass}`}
        style={{ height: `${height * 4}px` }}
      />
    );
  }

  return (
    <aside className="w-80 bg-slate-800 border-r border-slate-600 p-4 overflow-y-auto max-h-screen">
      
      {/* Binaural Beat Controls */}
      <section className="mb-6 bg-slate-750 rounded-lg p-4 border border-slate-600">
        <h3 className="text-lg font-semibold mb-4 flex items-center text-blue-300">
          <Headphones className="text-blue-400 mr-2 w-5 h-5" />
          Binaural Beats
        </h3>
        
        {/* Frequency Selection */}
        <div className="mb-4">
          <label className="block text-sm font-medium text-slate-300 mb-2">Frequency Range</label>
          <Select value={frequencyRange} onValueChange={onFrequencyRangeChange}>
            <SelectTrigger className="w-full bg-slate-800 border border-slate-600 text-slate-200">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="bg-slate-800 border-slate-600">
              <SelectItem value="delta">Delta (0.5-4 Hz)</SelectItem>
              <SelectItem value="theta">Theta (4-8 Hz)</SelectItem>
              <SelectItem value="alpha">Alpha (8-13 Hz)</SelectItem>
              <SelectItem value="beta">Beta (13-30 Hz)</SelectItem>
              <SelectItem value="gamma">Gamma (30-100 Hz)</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        {/* Precise Frequency Control */}
        <div className="mb-4">
          <label className="block text-sm font-medium text-slate-300 mb-2">Target Frequency</label>
          <div className="flex items-center space-x-2">
            <Slider
              value={[targetFrequency]}
              onValueChange={(value) => onTargetFrequencyChange(value[0])}
              min={range.min}
              max={range.max}
              step={0.1}
              className="flex-1"
            />
            <span className="text-sm font-mono text-slate-200 w-16">
              {targetFrequency.toFixed(1)} Hz
            </span>
          </div>
        </div>
        
        {/* Volume Control */}
        <div className="mb-4">
          <label className="block text-sm font-medium text-slate-300 mb-2">Beat Volume</label>
          <div className="flex items-center space-x-2">
            <span className="text-slate-400 text-sm">Low</span>
            <Slider
              value={[beatVolume]}
              onValueChange={(value) => onBeatVolumeChange(value[0])}
              min={0}
              max={100}
              step={1}
              className="flex-1"
            />
            <span className="text-slate-400 text-sm">High</span>
          </div>
        </div>
        
        {/* Playback Controls */}
        <div className="flex space-x-2">
          <Button 
            onClick={onToggleBinauralBeats}
            className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
          >
            {isPlayingBeats ? <Pause className="w-4 h-4 mr-2" /> : <Play className="w-4 h-4 mr-2" />}
            {isPlayingBeats ? 'Pause Beats' : 'Start Beats'}
          </Button>
          <Button 
            onClick={onStopBinauralBeats}
            variant="secondary"
            size="icon"
            className="bg-slate-600 hover:bg-slate-500"
          >
            <Square className="w-4 h-4" />
          </Button>
        </div>
      </section>

      {/* Advanced Controls */}
      <AdvancedControlPanel 
        whiteNoiseEnabled={whiteNoiseEnabled}
        whiteNoiseVolume={whiteNoiseVolume}
        whiteNoiseFrequency={whiteNoiseFrequency}
        onWhiteNoiseEnabledChange={onWhiteNoiseEnabledChange}
        onWhiteNoiseVolumeChange={onWhiteNoiseVolumeChange}
        onWhiteNoiseFrequencyChange={onWhiteNoiseFrequencyChange}
        isochronicEnabled={isochronicEnabled}
        isochronicRate={isochronicRate}
        onIsochronicEnabledChange={onIsochronicEnabledChange}
        onIsochronicRateChange={onIsochronicRateChange}
        frequencySweepEnabled={frequencySweepEnabled}
        sweepMin={sweepMin}
        sweepMax={sweepMax}
        onFrequencySweepEnabledChange={onFrequencySweepEnabledChange}
        onSweepMinChange={onSweepMinChange}
        onSweepMaxChange={onSweepMaxChange}
        dualBeatsEnabled={dualBeatsEnabled}
        secondaryBeat={secondaryBeat}
        onDualBeatsEnabledChange={onDualBeatsEnabledChange}
        onSecondaryBeatChange={onSecondaryBeatChange}
        monauralEnabled={monauralEnabled}
        onMonauralEnabledChange={onMonauralEnabledChange}
        harmonicLayering={harmonicLayering}
        onHarmonicLayeringChange={onHarmonicLayeringChange}
      />
      
      {/* Microphone Controls */}
      <section className="mb-6 bg-slate-750 rounded-lg p-4 border border-slate-600">
        <h3 className="text-lg font-semibold mb-4 flex items-center text-green-300">
          <Mic className="text-green-400 mr-2 w-5 h-5" />
          Voice Input
        </h3>
        
        {/* Input Gain */}
        <div className="mb-4">
          <label className="block text-sm font-medium text-slate-300 mb-2">Input Gain</label>
          <div className="flex items-center space-x-2">
            <span className="text-xs text-slate-400">Low</span>
            <Slider
              value={[inputGain]}
              onValueChange={(value) => onInputGainChange(value[0])}
              min={0}
              max={100}
              step={1}
              className="flex-1"
            />
            <span className="text-xs text-slate-400">High</span>
          </div>
        </div>
        
        {/* Input Level Meter */}
        <div className="mb-4">
          <label className="block text-sm font-medium text-slate-300 mb-2">Input Level</label>
          <div className="w-full bg-slate-600 rounded-full h-3">
            <div 
              className={`h-3 rounded-full transition-all duration-75 ${
                inputLevel > 80 ? 'bg-red-500' : 
                inputLevel > 50 ? 'bg-yellow-500' : 'bg-green-500'
              }`}
              style={{ width: `${Math.min(inputLevel, 100)}%` }}
            />
          </div>
          <div className="text-xs text-slate-400 mt-1 font-mono">{inputLevel.toFixed(1)}%</div>
        </div>
        
        {/* Recording Controls */}
        <div className="flex space-x-2">
          <Button 
            onClick={onToggleRecording}
            className={`flex-1 ${isRecording ? 'bg-red-600 hover:bg-red-700' : 'bg-green-600 hover:bg-green-700'} text-white`}
          >
            <div className={`w-2 h-2 rounded-full mr-2 ${isRecording ? 'bg-white animate-pulse' : 'bg-red-400'}`} />
            {isRecording ? 'Stop Recording' : 'Start Recording'}
          </Button>
        </div>
        
        {/* Error Display */}
        {microphoneError && (
          <div className="mt-2 p-2 bg-red-900/30 border border-red-600 rounded text-xs text-red-300">
            {microphoneError}
          </div>
        )}
        
        {/* Microphone Test */}
        <div className="mt-2 text-xs text-slate-400">
          Click "Start Recording" to test microphone access.
          <br />Check browser console for detailed logs.
        </div>
      </section>
      
      {/* Matching Analysis */}
      <section className="mb-6 bg-slate-750 rounded-lg p-4 border border-slate-600">
        <h3 className="text-lg font-semibold mb-4 flex items-center text-orange-300">
          <TrendingUp className="text-orange-400 mr-2 w-5 h-5" />
          Pattern Matching
        </h3>
        
        {/* Match Quality Indicator */}
        <div className="mb-4">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium text-slate-300">Match Quality</span>
            <span className="text-sm font-mono text-orange-400">{matchQuality}%</span>
          </div>
          <div className="w-full bg-slate-600 rounded-full h-3">
            <div 
              className="bg-gradient-to-r from-orange-500 to-yellow-400 h-3 rounded-full transition-all duration-300"
              style={{ width: `${matchQuality}%` }}
            />
          </div>
        </div>
        
        {/* Frequency Deviation */}
        <div className="mb-4">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium text-slate-300">Frequency Deviation</span>
            <span className="text-sm font-mono text-slate-400">
              {frequencyDeviation >= 0 ? '+' : ''}{frequencyDeviation} Hz
            </span>
          </div>
          <div className="text-xs text-slate-500">
            Target: {targetFrequency} Hz | Current: {inputFrequency} Hz
          </div>
        </div>
        
        {/* Calibration */}
        <Button 
          className="w-full bg-orange-600 hover:bg-orange-700 text-white"
          onClick={() => console.log('Calibrating system...')}
        >
          <Target className="w-4 h-4 mr-2" />
          Calibrate System
        </Button>
      </section>

      {/* MP3 Player */}
      <MP3Player />
      
    </aside>
  );
}
