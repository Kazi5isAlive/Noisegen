import { useEffect, useRef, useCallback } from 'react';
import { Circle, Sparkles } from 'lucide-react';

interface Bubble4DProps {
  frequencyBins: number[];
  targetFrequency: number;
  inputFrequency: number;
  matchQuality: number;
  isActive: boolean;
}

interface Bubble {
  x: number;
  y: number;
  z: number;
  w: number; // 4th dimension
  radius: number;
  intensity: number;
  phase: number;
  frequency: number;
  velocity: { x: number; y: number; z: number; w: number };
}

export function Bubble4D({ 
  frequencyBins, 
  targetFrequency, 
  inputFrequency, 
  matchQuality, 
  isActive 
}: Bubble4DProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationFrameRef = useRef<number>();
  const timeRef = useRef(0);
  const bubblesRef = useRef<Bubble[]>([]);

  const initializeBubbles = useCallback(() => {
    const bubbles: Bubble[] = [];
    const bubbleCount = 50;
    
    for (let i = 0; i < bubbleCount; i++) {
      bubbles.push({
        x: Math.random() * 400 - 200,
        y: Math.random() * 400 - 200,
        z: Math.random() * 400 - 200,
        w: Math.random() * Math.PI * 2, // 4D rotation phase
        radius: 5 + Math.random() * 15,
        intensity: Math.random(),
        phase: Math.random() * Math.PI * 2,
        frequency: 0.5 + Math.random() * 49.5,
        velocity: {
          x: (Math.random() - 0.5) * 0.5,
          y: (Math.random() - 0.5) * 0.5,
          z: (Math.random() - 0.5) * 0.5,
          w: (Math.random() - 0.5) * 0.02,
        }
      });
    }
    
    bubblesRef.current = bubbles;
  }, []);

  const project4DTo2D = useCallback((x: number, y: number, z: number, w: number, time: number) => {
    // 4D to 3D projection with rotation
    const cos4D = Math.cos(w + time * 0.001);
    const sin4D = Math.sin(w + time * 0.001);
    
    const x3D = x * cos4D - z * sin4D;
    const y3D = y;
    const z3D = x * sin4D + z * cos4D;
    
    // 3D to 2D perspective projection
    const distance = 300;
    const scale = distance / (distance + z3D);
    
    return {
      x: x3D * scale,
      y: y3D * scale,
      scale: scale,
      depth: z3D
    };
  }, []);

  const updateBubbles = useCallback((time: number) => {
    if (!isActive) return;
    
    bubblesRef.current.forEach((bubble, index) => {
      // Update position with velocity
      bubble.x += bubble.velocity.x;
      bubble.y += bubble.velocity.y;
      bubble.z += bubble.velocity.z;
      bubble.w += bubble.velocity.w;
      
      // Boundary wrapping
      if (Math.abs(bubble.x) > 200) bubble.x *= -0.8;
      if (Math.abs(bubble.y) > 200) bubble.y *= -0.8;
      if (Math.abs(bubble.z) > 200) bubble.z *= -0.8;
      
      // Frequency-based attraction to target
      const freqDiff = Math.abs(bubble.frequency - targetFrequency);
      const attraction = 1 / (1 + freqDiff);
      
      // Move towards center if frequency matches
      if (attraction > 0.8) {
        bubble.velocity.x += (0 - bubble.x) * 0.001;
        bubble.velocity.y += (0 - bubble.y) * 0.001;
        bubble.velocity.z += (0 - bubble.z) * 0.001;
      }
      
      // Update intensity based on frequency bins
      const binIndex = Math.floor((bubble.frequency / 50) * frequencyBins.length);
      if (binIndex < frequencyBins.length) {
        bubble.intensity = frequencyBins[binIndex] * attraction;
      }
      
      // Phase oscillation
      bubble.phase += 0.05 + bubble.intensity * 0.1;
      
      // Apply dampening
      bubble.velocity.x *= 0.99;
      bubble.velocity.y *= 0.99;
      bubble.velocity.z *= 0.99;
    });
  }, [frequencyBins, targetFrequency, isActive]);

  const drawBubbles = useCallback((ctx: CanvasRenderingContext2D, width: number, height: number, time: number) => {
    // Clear with fade effect
    ctx.fillStyle = 'rgba(7, 12, 23, 0.1)';
    ctx.fillRect(0, 0, width, height);
    
    const centerX = width / 2;
    const centerY = height / 2;
    
    // Sort bubbles by depth for proper rendering
    const sortedBubbles = [...bubblesRef.current].sort((a, b) => {
      const projA = project4DTo2D(a.x, a.y, a.z, a.w, time);
      const projB = project4DTo2D(b.x, b.y, b.z, b.w, time);
      return projB.depth - projA.depth;
    });
    
    sortedBubbles.forEach((bubble, index) => {
      const projected = project4DTo2D(bubble.x, bubble.y, bubble.z, bubble.w, time);
      
      const screenX = centerX + projected.x;
      const screenY = centerY + projected.y;
      const scaledRadius = bubble.radius * projected.scale;
      
      if (scaledRadius < 0.5) return; // Skip very small bubbles
      
      // Calculate color based on frequency and match quality
      const freqMatch = 1 - Math.abs(bubble.frequency - targetFrequency) / 50;
      const hue = bubble.frequency * 7.2; // Map frequency to hue
      const saturation = 70 + bubble.intensity * 30;
      const lightness = 40 + bubble.intensity * 40 + freqMatch * 20;
      const alpha = bubble.intensity * projected.scale * 0.8;
      
      // Draw bubble with cymatics-style interference patterns
      const oscillation = Math.sin(bubble.phase) * 0.3 + 0.7;
      const finalRadius = scaledRadius * oscillation;
      
      // Outer glow
      const gradient = ctx.createRadialGradient(
        screenX, screenY, 0,
        screenX, screenY, finalRadius * 2
      );
      gradient.addColorStop(0, `hsla(${hue}, ${saturation}%, ${lightness}%, ${alpha})`);
      gradient.addColorStop(0.7, `hsla(${hue}, ${saturation}%, ${lightness}%, ${alpha * 0.5})`);
      gradient.addColorStop(1, 'transparent');
      
      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.arc(screenX, screenY, finalRadius * 2, 0, Math.PI * 2);
      ctx.fill();
      
      // Inner bubble
      ctx.fillStyle = `hsla(${hue}, ${saturation}%, ${lightness + 20}%, ${alpha * 0.8})`;
      ctx.beginPath();
      ctx.arc(screenX, screenY, finalRadius, 0, Math.PI * 2);
      ctx.fill();
      
      // Highlight if close to target frequency
      if (freqMatch > 0.8) {
        ctx.strokeStyle = `hsla(${hue}, 90%, 80%, ${alpha})`;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(screenX, screenY, finalRadius * 1.2, 0, Math.PI * 2);
        ctx.stroke();
      }
      
      // Center core for very close matches
      if (freqMatch > 0.95) {
        ctx.fillStyle = `hsla(${hue}, 100%, 90%, ${alpha})`;
        ctx.beginPath();
        ctx.arc(screenX, screenY, finalRadius * 0.3, 0, Math.PI * 2);
        ctx.fill();
      }
    });
    
    // Draw frequency resonance field
    if (isActive && matchQuality > 50) {
      const fieldIntensity = matchQuality / 100;
      ctx.strokeStyle = `hsla(${targetFrequency * 7.2}, 70%, 60%, ${fieldIntensity * 0.3})`;
      ctx.lineWidth = 1;
      ctx.setLineDash([5, 5]);
      
      for (let r = 50; r < 200; r += 50) {
        ctx.beginPath();
        ctx.arc(centerX, centerY, r * fieldIntensity, 0, Math.PI * 2);
        ctx.stroke();
      }
      
      ctx.setLineDash([]);
    }
  }, [project4DTo2D, targetFrequency, matchQuality, isActive]);

  const animate = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;

    timeRef.current += 16;
    
    updateBubbles(timeRef.current);
    drawBubbles(ctx, canvas.width, canvas.height, timeRef.current);

    animationFrameRef.current = requestAnimationFrame(animate);
  }, [updateBubbles, drawBubbles]);

  useEffect(() => {
    initializeBubbles();
  }, [initializeBubbles]);

  useEffect(() => {
    if (isActive) {
      animate();
    } else {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    }

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [animate, isActive]);

  return (
    <section>
      <div className="flex justify-between items-center mb-3">
        <h4 className="text-sm font-medium text-slate-300 flex items-center">
          <Circle className="w-4 h-4 text-cyan-400 mr-2" />
          4D Bubble Cymatics
        </h4>
        <div className="flex items-center space-x-2">
          <Sparkles className="w-3 h-3 text-cyan-400" />
          <span className="text-xs text-slate-400">
            {bubblesRef.current.length} particles
          </span>
        </div>
      </div>
      
      <div className="bg-slate-900 rounded-xl border border-slate-600 relative overflow-hidden">
        <canvas 
          ref={canvasRef}
          className="w-full h-64"
          style={{ background: 'radial-gradient(circle, rgba(7,12,23,1) 0%, rgba(3,7,18,1) 100%)' }}
        />
        
        {!isActive && (
          <div className="absolute inset-0 flex items-center justify-center bg-slate-900/80">
            <div className="text-center">
              <Circle className="w-8 h-8 text-slate-500 mx-auto mb-2" />
              <p className="text-sm text-slate-400">Activate audio to see 4D cymatics</p>
            </div>
          </div>
        )}
        
        <div className="absolute bottom-2 left-2 text-xs text-slate-500">
          4D→2D Projection | Frequency Resonance Field
        </div>
        
        <div className="absolute bottom-2 right-2 text-xs text-slate-500">
          Match: {matchQuality}%
        </div>
      </div>
    </section>
  );
}