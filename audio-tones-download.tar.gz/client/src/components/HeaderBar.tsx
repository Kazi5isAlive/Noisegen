import { Waves, Mic, Settings } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface HeaderBarProps {
  isAudioReady: boolean;
  isRecording: boolean;
  recordingTime: string;
}

export function HeaderBar({ isAudioReady, isRecording, recordingTime }: HeaderBarProps) {
  return (
    <header className="bg-slate-750 border-b border-slate-600 px-6 py-4 flex items-center justify-between">
      <div className="flex items-center space-x-4">
        <Waves className="text-blue-500 text-2xl w-8 h-8" />
        <h1 className="text-2xl font-semibold">Theta Wave Tuner</h1>
        <span className="text-sm text-slate-400 font-mono">v2.1.0</span>
      </div>
      
      <div className="flex items-center space-x-4">
        {/* Audio Permission Status */}
        <div className="flex items-center space-x-2">
          <div className={`w-3 h-3 rounded-full ${isAudioReady ? 'bg-green-500 animate-pulse-glow' : 'bg-red-500'}`} />
          <span className="text-sm text-slate-300">
            {isAudioReady ? 'Audio Ready' : 'Audio Disabled'}
          </span>
        </div>
        
        {/* Recording Status */}
        <div className="flex items-center space-x-2">
          <Mic className={`w-5 h-5 ${isRecording ? 'text-red-500' : 'text-slate-400'}`} />
          <span className="text-sm text-slate-300 font-mono">{recordingTime}</span>
        </div>
        
        {/* Settings */}
        <Button variant="ghost" size="icon" className="p-2 hover:bg-slate-600 rounded-lg">
          <Settings className="w-5 h-5 text-slate-400" />
        </Button>
      </div>
    </header>
  );
}
