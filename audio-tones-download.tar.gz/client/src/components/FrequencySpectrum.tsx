interface FrequencySpectrumProps {
  frequencyBins: number[];
}

export function FrequencySpectrum({ frequencyBins }: FrequencySpectrumProps) {
  return (
    <div className="bg-slate-800 rounded-xl border border-slate-600 h-full">
      <div className="p-3 border-b border-slate-600">
        <h3 className="text-sm font-medium text-slate-300">Frequency Distribution</h3>
        <p className="text-xs text-slate-400">0-1000 Hz analysis</p>
      </div>
      <div className="p-4">

        
        {/* Frequency Bars */}
        <div className="flex items-end justify-between h-20 space-x-1">
          {frequencyBins.map((bin, index) => {
            const height = Math.max(5, bin * 80); // Min 5%, max based on bin value
            
            // Color gradient based on frequency range
            let colorClass = 'from-blue-600 to-blue-400';
            if (index >= 2 && index <= 4) colorClass = 'from-green-600 to-green-400';
            else if (index === 5) colorClass = 'from-yellow-600 to-yellow-400';
            else if (index === 6) colorClass = 'from-orange-600 to-orange-400';
            else if (index === 7) colorClass = 'from-red-600 to-red-400';
            else if (index >= 8) colorClass = 'from-slate-600 to-slate-500';
            
            return (
              <div
                key={index}
                className={`bg-gradient-to-t ${colorClass} rounded-t transition-all duration-150`}
                style={{ 
                  height: `${height}%`, 
                  width: '8px',
                  minHeight: '2px'
                }}
              />
            );
          })}
        </div>
        
        {/* Frequency Labels */}
        <div className="flex justify-between text-xs text-slate-500 mt-1 font-mono">
          <span>0</span>
          <span>100</span>
          <span>200</span>
          <span>300</span>
          <span>400</span>
          <span>500</span>
          <span>600</span>
          <span>700</span>
          <span>800</span>
          <span>900</span>
          <span>1K</span>
        </div>
      </div>
    </div>
  );
}
