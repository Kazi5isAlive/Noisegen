import { useEffect, useState, useRef, useCallback } from 'react';
import { useAudioContext } from './useAudioContext';

export function useMicrophoneInput() {
  const { audioContext, initializeAudioContext } = useAudioContext();
  const [isRecording, setIsRecording] = useState(false);
  const [inputLevel, setInputLevel] = useState(0);
  const [inputGain, setInputGain] = useState(60);
  const [error, setError] = useState<string | null>(null);
  
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const sourceNodeRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const analyserNodeRef = useRef<AnalyserNode | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);
  const animationFrameRef = useRef<number>();

  const updateInputLevel = useCallback(() => {
    if (!analyserNodeRef.current) return;

    const dataArray = new Uint8Array(analyserNodeRef.current.frequencyBinCount);
    analyserNodeRef.current.getByteTimeDomainData(dataArray);
    
    // Calculate RMS (Root Mean Square) for input level
    let sum = 0;
    for (let i = 0; i < dataArray.length; i++) {
      const normalized = (dataArray[i] - 128) / 128; // Convert to -1 to 1 range
      sum += normalized * normalized;
    }
    const rms = Math.sqrt(sum / dataArray.length);
    setInputLevel(rms * 100); // Convert to percentage

    animationFrameRef.current = requestAnimationFrame(updateInputLevel);
  }, []);

  const startRecording = async () => {
    try {
      setError(null);
      console.log('Starting microphone recording...');
      
      // Check if navigator.mediaDevices is available
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('MediaDevices API not supported in this browser');
      }

      // Initialize audio context if needed
      const context = await initializeAudioContext();
      console.log('Audio context initialized:', context.state);
      
      // Request microphone access
      console.log('Requesting microphone permission...');
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: false,
          noiseSuppression: false,
          autoGainControl: false,
          sampleRate: 44100,
        }
      });

      console.log('Microphone access granted, stream:', stream.getAudioTracks());
      mediaStreamRef.current = stream;

      // Create audio nodes
      const source = context.createMediaStreamSource(stream);
      const analyser = context.createAnalyser();
      const gainNode = context.createGain();

      // Configure analyser for better frequency detection
      analyser.fftSize = 4096; // Higher resolution for better frequency detection
      analyser.smoothingTimeConstant = 0.1; // More responsive
      analyser.minDecibels = -100;
      analyser.maxDecibels = -10;

      // Set initial gain
      gainNode.gain.value = inputGain / 100;

      // Connect nodes
      source.connect(gainNode);
      gainNode.connect(analyser);

      sourceNodeRef.current = source;
      analyserNodeRef.current = analyser;
      gainNodeRef.current = gainNode;

      console.log('Audio pipeline connected successfully');
      setIsRecording(true);
      updateInputLevel();

    } catch (err) {
      let errorMessage = 'Failed to access microphone';
      
      if (err instanceof Error) {
        if (err.name === 'NotAllowedError') {
          errorMessage = 'Microphone permission denied. Please allow microphone access and try again.';
        } else if (err.name === 'NotFoundError') {
          errorMessage = 'No microphone found. Please connect a microphone and try again.';
        } else if (err.name === 'NotReadableError') {
          errorMessage = 'Microphone is being used by another application.';
        } else {
          errorMessage = err.message;
        }
      }
      
      setError(errorMessage);
      console.error('Microphone access error:', err);
    }
  };

  const stopRecording = () => {
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
    }

    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach(track => track.stop());
      mediaStreamRef.current = null;
    }

    sourceNodeRef.current = null;
    analyserNodeRef.current = null;
    gainNodeRef.current = null;
    
    setIsRecording(false);
    setInputLevel(0);
  };

  const toggleRecording = () => {
    if (isRecording) {
      stopRecording();
    } else {
      startRecording();
    }
  };

  // Update gain when inputGain changes
  useEffect(() => {
    if (gainNodeRef.current) {
      gainNodeRef.current.gain.value = inputGain / 100;
    }
  }, [inputGain]);

  useEffect(() => {
    return () => {
      stopRecording();
    };
  }, []);

  return {
    isRecording,
    inputLevel,
    inputGain,
    setInputGain,
    error,
    analyserNode: analyserNodeRef.current,
    startRecording,
    stopRecording,
    toggleRecording,
  };
}
