import { useEffect, useState, useRef, useCallback } from 'react';
import { useAudioContext } from './useAudioContext';

type FrequencyRange = 'delta' | 'theta' | 'alpha' | 'beta' | 'gamma';

const FREQUENCY_RANGES = {
  delta: { min: 0.5, max: 4, default: 2 },
  theta: { min: 4, max: 8, default: 6 },
  alpha: { min: 8, max: 13, default: 10 },
  beta: { min: 13, max: 30, default: 20 },
  gamma: { min: 30, max: 100, default: 40 },
};

const BASE_FREQUENCY = 200; // Hz - better for binaural beats

export function useBinauralBeats() {
  const { initializeAudioContext } = useAudioContext();
  const [isPlaying, setIsPlaying] = useState(false);
  const [frequencyRange, setFrequencyRange] = useState<FrequencyRange>('theta');
  const [targetFrequency, setTargetFrequency] = useState(5);
  const [beatVolume, setBeatVolume] = useState(80);
  const [whiteNoiseEnabled, setWhiteNoiseEnabled] = useState(false);
  const [whiteNoiseVolume, setWhiteNoiseVolume] = useState(15);
  const [whiteNoiseFrequency, setWhiteNoiseFrequency] = useState(19000);
  const [isochronicEnabled, setIsochronicEnabled] = useState(false);
  const [isochronicRate, setIsochronicRate] = useState(5);
  const [outputAnalyserNode, setOutputAnalyserNode] = useState<AnalyserNode | null>(null);

  const [error, setError] = useState<string | null>(null);

  // Audio nodes refs
  const audioNodesRef = useRef<{
    leftOsc?: OscillatorNode;
    rightOsc?: OscillatorNode;
    leftGain?: GainNode;
    rightGain?: GainNode;
    pannerLeft?: StereoPannerNode;
    pannerRight?: StereoPannerNode;
    whiteNoise?: AudioBufferSourceNode;
    whiteNoiseGain?: GainNode;
    whiteNoiseFilter?: BiquadFilterNode;
    isochronicOsc?: OscillatorNode;
    isochronicGain?: GainNode;
    isochronicLFO?: OscillatorNode;
    secondaryOscLeft?: OscillatorNode;
    secondaryOscRight?: OscillatorNode;
    monauralOscs?: OscillatorNode[];
    harmonicOscs?: OscillatorNode[];
    sweepInterval?: NodeJS.Timeout;
  }>({});



  // Stop all audio nodes
  const stopAllNodes = useCallback(() => {
    const nodes = audioNodesRef.current;
    
    // Stop oscillators safely
    [nodes.leftOsc, nodes.rightOsc, nodes.isochronicOsc, nodes.isochronicLFO,
     nodes.secondaryOscLeft, nodes.secondaryOscRight, nodes.whiteNoise].forEach(node => {
      if (node) {
        try {
          node.stop();
        } catch (e) {
          // Node may already be stopped
        }
      }
    });

    // Stop monaural oscillators
    if (nodes.monauralOscs) {
      nodes.monauralOscs.forEach(osc => {
        try { osc.stop(); } catch (e) {}
      });
    }

    // Stop harmonic oscillators
    if (nodes.harmonicOscs) {
      nodes.harmonicOscs.forEach(osc => {
        try { osc.stop(); } catch (e) {}
      });
    }

    // Clear interval
    if (nodes.sweepInterval) {
      clearInterval(nodes.sweepInterval);
    }

    // Reset refs
    audioNodesRef.current = {};
    setOutputAnalyserNode(null);
    setIsPlaying(false);
  }, []);

  // Create white noise buffer
  const createWhiteNoiseBuffer = useCallback((context: AudioContext) => {
    const bufferSize = context.sampleRate * 2;
    const buffer = context.createBuffer(1, bufferSize, context.sampleRate);
    const output = buffer.getChannelData(0);
    
    for (let i = 0; i < bufferSize; i++) {
      output[i] = Math.random() * 2 - 1;
    }
    
    return buffer;
  }, []);

  // Handle white noise independently
  const toggleWhiteNoise = useCallback(async () => {
    try {
      const context = await initializeAudioContext();
      if (!context) return;

      const nodes = audioNodesRef.current;
      
      if (whiteNoiseEnabled && !nodes.whiteNoise) {
        // Start white noise
        const whiteNoise = context.createBufferSource();
        const whiteNoiseGain = context.createGain();
        const whiteNoiseFilter = context.createBiquadFilter();
        
        whiteNoise.buffer = createWhiteNoiseBuffer(context);
        whiteNoise.loop = true;
        whiteNoiseFilter.type = 'bandpass';
        whiteNoiseFilter.frequency.value = whiteNoiseFrequency;
        whiteNoiseFilter.Q.value = 0.5;
        whiteNoiseGain.gain.value = whiteNoiseVolume / 100;
        
        whiteNoise.connect(whiteNoiseFilter);
        whiteNoiseFilter.connect(whiteNoiseGain);
        whiteNoiseGain.connect(context.destination);
        whiteNoise.start();
        
        nodes.whiteNoise = whiteNoise;
        nodes.whiteNoiseGain = whiteNoiseGain;
        nodes.whiteNoiseFilter = whiteNoiseFilter;
      } else if (!whiteNoiseEnabled && nodes.whiteNoise) {
        // Stop white noise
        try { nodes.whiteNoise.stop(); } catch (e) {}
        delete nodes.whiteNoise;
        delete nodes.whiteNoiseGain;
        delete nodes.whiteNoiseFilter;
      }
    } catch (error) {
      console.error('White noise error:', error);
    }
  }, [whiteNoiseEnabled, whiteNoiseVolume, whiteNoiseFrequency, initializeAudioContext, createWhiteNoiseBuffer]);

  // Create binaural beat
  const createBinauralBeat = useCallback(async () => {
    try {
      console.log('Creating binaural beat...');
      const context = await initializeAudioContext();
      if (!context) throw new Error('Failed to initialize audio context');
      
      console.log('Audio context ready, frequency:', targetFrequency);
      
      // Stop any existing audio first
      stopAllNodes();

      // Create output analyser for visualization
      const outputAnalyser = context.createAnalyser();
      outputAnalyser.fftSize = 2048;
      outputAnalyser.smoothingTimeConstant = 0.8;
      setOutputAnalyserNode(outputAnalyser);
      
      const nodes = audioNodesRef.current;
      
      // Create main binaural beat oscillators
      const leftOsc = context.createOscillator();
      const rightOsc = context.createOscillator();
      const leftGain = context.createGain();
      const rightGain = context.createGain();
      const pannerLeft = context.createStereoPanner();
      const pannerRight = context.createStereoPanner();
      
      // Configure main audio tones
      leftOsc.frequency.value = BASE_FREQUENCY;
      rightOsc.frequency.value = BASE_FREQUENCY + targetFrequency;
      leftOsc.type = 'sine';
      rightOsc.type = 'sine';
      
      const volume = (beatVolume / 100) * 0.3; // Convert percentage to decimal
      leftGain.gain.value = volume;
      rightGain.gain.value = volume;
      
      pannerLeft.pan.value = -1;
      pannerRight.pan.value = 1;
      
      // Connect main binaural beats
      leftOsc.connect(leftGain);
      leftGain.connect(pannerLeft);
      pannerLeft.connect(outputAnalyser);
      
      rightOsc.connect(rightGain);
      rightGain.connect(pannerRight);
      pannerRight.connect(outputAnalyser);
      
      outputAnalyser.connect(context.destination);
      
      // Store main references
      nodes.leftOsc = leftOsc;
      nodes.rightOsc = rightOsc;
      nodes.leftGain = leftGain;
      nodes.rightGain = rightGain;
      nodes.pannerLeft = pannerLeft;
      nodes.pannerRight = pannerRight;
      
      // Add white noise if enabled
      if (whiteNoiseEnabled) {
        const whiteNoise = context.createBufferSource();
        const whiteNoiseGain = context.createGain();
        const whiteNoiseFilter = context.createBiquadFilter();
        
        whiteNoise.buffer = createWhiteNoiseBuffer(context);
        whiteNoise.loop = true;
        whiteNoiseFilter.type = 'bandpass';
        whiteNoiseFilter.frequency.value = whiteNoiseFrequency;
        whiteNoiseFilter.Q.value = 0.5;
        whiteNoiseGain.gain.value = whiteNoiseVolume / 100;
        
        whiteNoise.connect(whiteNoiseFilter);
        whiteNoiseFilter.connect(whiteNoiseGain);
        whiteNoiseGain.connect(outputAnalyser);
        
        nodes.whiteNoise = whiteNoise;
        nodes.whiteNoiseGain = whiteNoiseGain;
        whiteNoise.start();
      }
      
      // Add isochronic tones if enabled
      if (isochronicEnabled) {
        const isoOsc = context.createOscillator();
        const isoGain = context.createGain();
        const isoLFO = context.createOscillator();
        
        isoOsc.frequency.value = BASE_FREQUENCY;
        isoOsc.type = 'sine';
        isoLFO.frequency.value = isochronicRate;
        isoLFO.type = 'square';
        
        // Set up proper isochronic modulation
        isoGain.gain.value = 0; // Start at zero
        const lfoGain = context.createGain();
        lfoGain.gain.value = volume * 0.2; // Modulation depth
        
        isoLFO.connect(lfoGain);
        lfoGain.connect(isoGain.gain);
        isoOsc.connect(isoGain);
        isoGain.connect(outputAnalyser);
        
        nodes.isochronicOsc = isoOsc;
        nodes.isochronicGain = isoGain;
        nodes.isochronicLFO = isoLFO;
        isoOsc.start();
        isoLFO.start();
      }
      

      

      

      
      // Start main oscillators
      leftOsc.start();
      rightOsc.start();
      
      console.log('Audio tones started successfully, volume:', volume, 'raw volume:', beatVolume);
      setError(null);
      return true;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to create binaural beats';
      setError(errorMessage);
      console.error('Binaural beats error:', err);
      return false;
    }
  }, [targetFrequency, beatVolume, whiteNoiseEnabled, whiteNoiseVolume, whiteNoiseFrequency, 
      isochronicEnabled, isochronicRate,
      initializeAudioContext, createWhiteNoiseBuffer, stopAllNodes]);

  // Start binaural beats
  const startBinauralBeats = useCallback(async () => {
    try {
      console.log('Starting binaural beats...');
      const success = await createBinauralBeat();
      if (success) {
        setIsPlaying(true);
        console.log('Audio tones playing state set to true');
      } else {
        console.log('Failed to create binaural beat');
      }
    } catch (err) {
      console.error('Failed to start binaural beats:', err);
      setError(err instanceof Error ? err.message : 'Failed to start audio tones');
    }
  }, [createBinauralBeat]);

  // Toggle audio tones
  const toggleBinauralBeats = useCallback(() => {
    console.log('Toggle audio tones, current state:', isPlaying);
    if (isPlaying) {
      console.log('Stopping audio tones');
      stopAllNodes();
    } else {
      console.log('Starting audio tones');
      startBinauralBeats();
    }
  }, [isPlaying, stopAllNodes, startBinauralBeats]);

  // Update frequency range when changed
  const updateFrequencyRange = useCallback((range: FrequencyRange) => {
    setFrequencyRange(range);
    const newDefault = FREQUENCY_RANGES[range].default;
    setTargetFrequency(newDefault);
  }, []);

  // Update volume when beatVolume changes
  useEffect(() => {
    const nodes = audioNodesRef.current;
    if (nodes.leftGain && nodes.rightGain) {
      const volume = (beatVolume / 100) * 0.3;
      nodes.leftGain.gain.value = volume;
      nodes.rightGain.gain.value = volume;
    }
  }, [beatVolume]);

  // Update frequency when targetFrequency changes
  useEffect(() => {
    const nodes = audioNodesRef.current;
    if (nodes.rightOsc) {
      nodes.rightOsc.frequency.value = BASE_FREQUENCY + targetFrequency;
    }
  }, [targetFrequency]);

  // Update white noise when enabled/disabled
  useEffect(() => {
    toggleWhiteNoise();
  }, [whiteNoiseEnabled, toggleWhiteNoise]);

  // Update white noise volume in real-time
  useEffect(() => {
    const nodes = audioNodesRef.current;
    if (nodes.whiteNoiseGain) {
      nodes.whiteNoiseGain.gain.value = whiteNoiseVolume / 100;
    }
  }, [whiteNoiseVolume]);

  // Update white noise frequency filter in real-time
  useEffect(() => {
    const nodes = audioNodesRef.current;
    if (nodes.whiteNoiseFilter) {
      nodes.whiteNoiseFilter.frequency.value = whiteNoiseFrequency;
    }
  }, [whiteNoiseFrequency]);

  // Update isochronic rate in real-time
  useEffect(() => {
    const nodes = audioNodesRef.current;
    if (nodes.isochronicLFO) {
      nodes.isochronicLFO.frequency.value = isochronicRate;
    }
  }, [isochronicRate]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopAllNodes();
    };
  }, [stopAllNodes]);

  return {
    isPlaying,
    frequencyRange,
    targetFrequency,
    beatVolume,
    outputAnalyserNode,
    whiteNoiseEnabled,
    whiteNoiseVolume,
    whiteNoiseFrequency,
    isochronicEnabled,
    isochronicRate,

    error,
    frequencyRanges: FREQUENCY_RANGES,
    setTargetFrequency,
    setBeatVolume,
    setWhiteNoiseEnabled,
    setWhiteNoiseVolume,
    setWhiteNoiseFrequency,
    setIsochronicEnabled,
    setIsochronicRate,
    updateFrequencyRange,
    startBinauralBeats,
    stopBinauralBeats: stopAllNodes,
    toggleBinauralBeats,
  };
}