import { useEffect, useState, useRef, useCallback } from 'react';

interface FrequencyData {
  inputFrequency: number;
  matchQuality: number;
  frequencyDeviation: number;
  frequencyBins: number[];
}

export function useFrequencyAnalysis(
  analyserNode: AnalyserNode | null,
  targetFrequency: number
) {
  const [frequencyData, setFrequencyData] = useState<FrequencyData>({
    inputFrequency: 0,
    matchQuality: 0,
    frequencyDeviation: 0,
    frequencyBins: new Array(15).fill(0),
  });

  const animationFrameRef = useRef<number>();

  const analyzeFrequency = useCallback(() => {
    if (!analyserNode) return;

    const bufferLength = analyserNode.frequencyBinCount;
    const dataArray = new Float32Array(bufferLength);
    const freqArray = new Uint8Array(bufferLength);
    
    analyserNode.getFloatFrequencyData(dataArray);
    analyserNode.getByteFrequencyData(freqArray);

    // Calculate sample rate and frequency resolution
    const sampleRate = analyserNode.context.sampleRate;
    const frequencyResolution = sampleRate / (2 * bufferLength);

    // Find dominant frequency
    let maxMagnitude = -Infinity;
    let dominantFrequencyBin = 0;

    // Focus on human vocal range (80-1000 Hz) for better voice detection
    const minBin = Math.floor(80 / frequencyResolution);
    const maxBin = Math.min(Math.floor(1000 / frequencyResolution), bufferLength);
    
    for (let i = minBin; i < maxBin; i++) {
      if (dataArray[i] > maxMagnitude && dataArray[i] > -50) { // Only consider significant signals
        maxMagnitude = dataArray[i];
        dominantFrequencyBin = i;
      }
    }

    const inputFrequency = dominantFrequencyBin * frequencyResolution;
    
    // Calculate frequency deviation
    const frequencyDeviation = inputFrequency - targetFrequency;
    
    // Calculate match quality (0-100%) - more sensitive for theta wave matching
    const maxDeviation = Math.max(1, targetFrequency * 0.05); // Tighter tolerance for precise matching
    const normalizedDeviation = Math.abs(frequencyDeviation) / maxDeviation;
    const matchQuality = Math.max(0, Math.min(100, (1 - normalizedDeviation) * 100));

    // Create frequency bins for visualization (0-1000 Hz range)
    const binCount = 15;
    const totalRange = Math.min(Math.floor(1000 / frequencyResolution), bufferLength);
    const binsPerGroup = Math.floor(totalRange / binCount);
    const frequencyBins: number[] = [];

    for (let i = 0; i < binCount; i++) {
      let sum = 0;
      const startBin = i * binsPerGroup;
      const endBin = Math.min(startBin + binsPerGroup, totalRange);
      
      for (let j = startBin; j < endBin; j++) {
        // Convert from dB to linear scale and normalize
        const normalizedValue = Math.max(0, (dataArray[j] + 100) / 100);
        sum += normalizedValue;
      }
      
      frequencyBins.push(sum / binsPerGroup);
    }

    setFrequencyData({
      inputFrequency: Number(inputFrequency.toFixed(1)),
      matchQuality: Number(matchQuality.toFixed(0)),
      frequencyDeviation: Number(frequencyDeviation.toFixed(1)),
      frequencyBins,
    });

    animationFrameRef.current = requestAnimationFrame(analyzeFrequency);
  }, [analyserNode, targetFrequency]);

  useEffect(() => {
    if (analyserNode) {
      analyzeFrequency();
    } else {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
      // Reset to default values when no analyser
      setFrequencyData({
        inputFrequency: 0,
        matchQuality: 0,
        frequencyDeviation: 0,
        frequencyBins: new Array(15).fill(0),
      });
    }

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [analyzeFrequency]);

  return frequencyData;
}
