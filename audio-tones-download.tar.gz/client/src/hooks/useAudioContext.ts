import { useEffect, useState, useRef } from 'react';

export function useAudioContext() {
  const [audioContext, setAudioContext] = useState<AudioContext | null>(null);
  const [isInitialized, setIsInitialized] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const contextRef = useRef<AudioContext | null>(null);

  const initializeAudioContext = async () => {
    try {
      if (contextRef.current) {
        if (contextRef.current.state === 'suspended') {
          await contextRef.current.resume();
        }
        return contextRef.current;
      }

      const context = new (window.AudioContext || (window as any).webkitAudioContext)();
      contextRef.current = context;
      setAudioContext(context);
      setIsInitialized(true);
      setError(null);
      return context;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to initialize audio context';
      setError(errorMessage);
      throw err;
    }
  };

  const resumeAudioContext = async () => {
    if (contextRef.current && contextRef.current.state === 'suspended') {
      try {
        await contextRef.current.resume();
      } catch (err) {
        console.error('Failed to resume audio context:', err);
      }
    }
  };

  useEffect(() => {
    return () => {
      if (contextRef.current && contextRef.current.state !== 'closed') {
        contextRef.current.close();
      }
    };
  }, []);

  return {
    audioContext,
    isInitialized,
    error,
    initializeAudioContext,
    resumeAudioContext,
  };
}
