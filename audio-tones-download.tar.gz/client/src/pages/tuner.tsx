import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Mic, MicOff, Headphones, AlertCircle, Volume2 } from 'lucide-react';

import { useBinauralBeats } from '@/hooks/useBinauralBeats';
import { useMicrophoneInput } from '@/hooks/useMicrophoneInput';
import { useFrequencyAnalysis } from '@/hooks/useFrequencyAnalysis';
import { useAudioContext } from '@/hooks/useAudioContext';

import { WaveformCanvas } from '@/components/WaveformCanvas';
import { VoicePatternMatcher } from '@/components/VoicePatternMatcher';

// Helper function to get musical note from frequency
function getMusicalNote(frequency: number): string {
  if (frequency === 0) return "—";
  
  const A4 = 440;
  const C0 = A4 * Math.pow(2, -4.75);
  
  const noteNames = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"];
  
  const h = Math.round(12 * Math.log2(frequency / C0));
  const octave = Math.floor(h / 12);
  const n = h % 12;
  
  return noteNames[n] + octave;
}

export default function TunerPage() {
  const [recordingTime, setRecordingTime] = useState('00:00');
  const [recordingStartTime, setRecordingStartTime] = useState<number | null>(null);

  // Audio hooks
  const { audioContext, isAudioReady } = useAudioContext();
  const {
    isRecording,
    inputLevel,
    inputGain,
    error: microphoneError,
    analyserNode,
    toggleRecording,
    setInputGain
  } = useMicrophoneInput();

  const {
    isPlaying: isPlayingBeats,
    frequencyRange,
    targetFrequency,
    beatVolume,
    error,
    outputAnalyserNode,
    // Additional features
    whiteNoiseEnabled, whiteNoiseVolume, whiteNoiseFrequency,
    isochronicEnabled, isochronicRate,

    toggleBinauralBeats,
    updateFrequencyRange,
    setTargetFrequency,
    setBeatVolume,
    setWhiteNoiseEnabled, setWhiteNoiseVolume, setWhiteNoiseFrequency,
    setIsochronicEnabled, setIsochronicRate,

  } = useBinauralBeats();

  const {
    inputFrequency,
    matchQuality,
    frequencyDeviation,
    frequencyBins
  } = useFrequencyAnalysis(analyserNode, targetFrequency);

  // Recording timer
  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (isRecording) {
      if (!recordingStartTime) {
        setRecordingStartTime(Date.now());
      }
      
      interval = setInterval(() => {
        if (recordingStartTime) {
          const elapsed = Date.now() - recordingStartTime;
          const minutes = Math.floor(elapsed / 60000);
          const seconds = Math.floor((elapsed % 60000) / 1000);
          setRecordingTime(`${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`);
        }
      }, 1000);
    } else {
      setRecordingStartTime(null);
      setRecordingTime('00:00');
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isRecording, recordingStartTime]);

  return (
    <div className="min-h-screen bg-slate-900 text-white">
      
      {/* Top Status Bar */}
      <div className="bg-slate-800 border-b border-slate-600 px-4 py-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              {isRecording ? (
                <Mic className="w-4 h-4 text-green-400" />
              ) : (
                <MicOff className="w-4 h-4 text-slate-400" />
              )}
              <span className="text-sm font-mono">{recordingTime}</span>
            </div>
            
            <div className="text-slate-400">|</div>
            
            <div className="text-sm">
              <span className="text-slate-400">Voice:</span>
              <span className="text-green-400 ml-1 font-mono">{(inputFrequency || 0).toFixed(1)}Hz</span>
            </div>
            
            <div className="text-sm">
              <span className="text-slate-400">Note:</span>
              <span className="text-white ml-1">{inputFrequency > 0 ? getMusicalNote(inputFrequency) : "—"}</span>
            </div>
          </div>
        </div>
      </div>



      <div className="flex">
        {/* Left Sidebar - Controls */}
        <aside className="w-72 bg-slate-800 border-r border-slate-600 p-4">
          
          {/* MICROPHONE */}
          <div className="bg-slate-700 rounded p-4 mb-4">
            <h3 className="text-sm font-semibold text-green-300 mb-3">🎤 MICROPHONE</h3>
            
            <Button 
              onClick={toggleRecording}
              className={`w-full h-12 text-sm font-bold ${
                isRecording 
                  ? "bg-red-600 hover:bg-red-700" 
                  : "bg-green-600 hover:bg-green-700"
              }`}
            >
              {isRecording ? (
                <>
                  <MicOff className="w-4 h-4 mr-2" />
                  STOP
                </>
              ) : (
                <>
                  <Mic className="w-4 h-4 mr-2" />
                  START
                </>
              )}
            </Button>

            {/* Input Level */}
            {isRecording && (
              <div className="mt-3">
                <div className="text-xs text-green-300 mb-1">Level: {(inputLevel || 0).toFixed(0)}%</div>
                <div className="w-full bg-slate-600 rounded h-2">
                  <div 
                    className="h-2 rounded bg-green-400"
                    style={{ width: `${Math.min(inputLevel || 0, 100)}%` }}
                  />
                </div>
              </div>
            )}

            {/* Error Display */}
            {microphoneError && (
              <div className="mt-3 p-2 bg-red-900 border border-red-600 rounded text-xs">
                <div className="flex items-center gap-1">
                  <AlertCircle className="w-3 h-3 text-red-400" />
                  <span className="text-red-300">Error:</span>
                </div>
                <p className="text-red-200 mt-1">{microphoneError}</p>
              </div>
            )}

            {/* Input Gain */}
            <div className="mt-3">
              <label className="text-xs text-slate-300 mb-1 block">Gain: {(inputGain || 0).toFixed(1)}x</label>
              <Slider
                value={[inputGain]}
                onValueChange={(value) => setInputGain(value[0])}
                min={0}
                max={2}
                step={0.1}
                className="w-full"
              />
            </div>
          </div>

          {/* AUDIO TONES */}
          <div className="bg-slate-700 rounded p-4 mb-4">
            <h3 className="text-sm font-semibold text-blue-300 mb-3">
              <Headphones className="inline w-4 h-4 mr-2" />
              Audio Tones
            </h3>
            
            <Button 
              onClick={toggleBinauralBeats}
              className={`w-full h-10 text-sm mb-3 ${
                isPlayingBeats 
                  ? "bg-blue-600 hover:bg-blue-700" 
                  : "bg-slate-600 hover:bg-slate-500"
              }`}
            >
              {isPlayingBeats ? "STOP" : "START"}
            </Button>

            {/* Frequency Range Selection */}
            <div className="mb-3">
              <label className="text-xs text-slate-300 mb-1 block">Brain Wave Range</label>
              <select 
                value={frequencyRange} 
                onChange={(e) => updateFrequencyRange(e.target.value as any)}
                className="w-full bg-slate-600 text-white p-2 rounded text-xs"
              >
                <option value="delta">Delta (0.5-4 Hz) - Deep Sleep</option>
                <option value="theta">Theta (4-8 Hz) - Meditation</option>
                <option value="alpha">Alpha (8-13 Hz) - Relaxation</option>
                <option value="beta">Beta (13-30 Hz) - Focus</option>
                <option value="gamma">Gamma (30-40 Hz) - Awareness</option>
              </select>
            </div>

            {/* Harmony Frequency */}
            <div className="mb-3">
              <label className="text-xs text-slate-300 mb-1 block">
                Harmony Frequency: {targetFrequency.toFixed(1)} Hz
              </label>
              <Slider
                value={[targetFrequency]}
                onValueChange={(value) => setTargetFrequency(value[0])}
                min={0.5}
                max={40}
                step={0.1}
                className="w-full"
              />
              <div className="text-xs text-slate-400 mt-1">
                Match patterns, not exact pitch
              </div>
            </div>

            {/* Volume Control */}
            <div className="mb-3">
              <label className="text-xs text-slate-300 mb-1 block">
                Volume: {Math.round(beatVolume * 100)}%
              </label>
              <Slider
                value={[beatVolume]}
                onValueChange={(value) => setBeatVolume(value[0])}
                min={0}
                max={1}
                step={0.01}
                className="w-full"
              />
            </div>



            {/* Error Display */}
            {error && (
              <div className="mt-3 p-2 bg-red-900 border border-red-600 rounded text-xs text-red-300">
                {error}
              </div>
            )}
          </div>

          {/* WHITE NOISE QUICK TOGGLE */}
          <div className="bg-slate-700 rounded p-4 mb-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold text-purple-300">
                <Volume2 className="inline w-4 h-4 mr-2" />
                White Noise
              </h3>
              <Button 
                onClick={() => setWhiteNoiseEnabled(!whiteNoiseEnabled)}
                className={`px-4 py-2 text-xs ${
                  whiteNoiseEnabled 
                    ? "bg-purple-600 hover:bg-purple-700" 
                    : "bg-slate-600 hover:bg-slate-500"
                }`}
              >
                {whiteNoiseEnabled ? "ON" : "OFF"}
              </Button>
            </div>
            
            {whiteNoiseEnabled && (
              <div className="space-y-2">
                <div>
                  <label className="text-xs text-slate-300 mb-1 block">
                    Volume: {whiteNoiseVolume}%
                  </label>
                  <Slider
                    value={[whiteNoiseVolume]}
                    onValueChange={(value) => setWhiteNoiseVolume(value[0])}
                    min={0}
                    max={100}
                    step={1}
                    className="w-full"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-300 mb-1 block">
                    Filter: {whiteNoiseFrequency} Hz
                  </label>
                  <Slider
                    value={[whiteNoiseFrequency]}
                    onValueChange={(value) => setWhiteNoiseFrequency(value[0])}
                    min={100}
                    max={19000}
                    step={100}
                    className="w-full"
                  />
                </div>
              </div>
            )}
          </div>



          {/* Stats */}
          <div className="bg-slate-700 rounded p-3 text-xs">
            <div className="flex justify-between mb-1">
              <span className="text-slate-400">Note:</span>
              <span className="text-white">{inputFrequency > 0 ? getMusicalNote(inputFrequency) : "—"}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Level:</span>
              <span className="text-white">{(inputLevel || 0).toFixed(0)}%</span>
            </div>
          </div>
        </aside>

        {/* Main Content with Parallel Windows */}
        <main className="flex-1 bg-slate-900">
          
          {/* Voice Frequency Display */}
          <div className="text-center py-4">
            <div className="text-4xl font-bold text-green-400 mb-1">{(inputFrequency || 0).toFixed(1)}</div>
            <div className="text-lg text-slate-400">Hz</div>
            <div className="text-sm text-slate-500">{inputFrequency > 0 ? getMusicalNote(inputFrequency) : "—"}</div>
          </div>

          {/* Parallel Windows - Side by Side */}
          <div className="flex h-96 gap-1">
            {/* Left Window - Voice Recording ONLY */}
            <div className="w-1/2 bg-slate-800 border border-slate-600 rounded-lg p-3">
              <h3 className="text-xs font-medium text-green-300 mb-2">Voice Recording</h3>
              <div className="h-full bg-slate-900 rounded">
                <WaveformCanvas 
                  analyserNode={analyserNode}
                  targetFrequency={0}
                  inputFrequency={inputFrequency}
                  isRecording={isRecording}
                />
              </div>
            </div>

            {/* Right Window - Audio Tones Pattern */}
            <div className="w-1/2 bg-slate-800 border border-slate-600 rounded-lg p-3">
              <h3 className="text-xs font-medium text-orange-300 mb-2">Audio Tones Pattern</h3>
              <div className="h-full bg-slate-900 rounded">
                <VoicePatternMatcher
                  analyserNode={analyserNode}
                  isRecording={isRecording}
                  targetFrequency={targetFrequency}
                  beatVolume={beatVolume}
                />
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}